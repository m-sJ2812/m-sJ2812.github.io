module ModernResumeTheme
  VERSION = "2.0.10"
end
